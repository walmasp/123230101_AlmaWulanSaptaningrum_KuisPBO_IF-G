/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany._almawulansaptaningrum_kuispbo_if.g;

/**
 *
 * @author Lenovo
 */
public class Main {

    public static void main(String[] args) {
        new LoginPage();
    }
}
